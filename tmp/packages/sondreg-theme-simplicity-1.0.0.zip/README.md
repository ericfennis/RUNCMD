![](https://raw.githubusercontent.com/sondregi/pagekit-theme-simplicity/develop/image.png)

# Theme Simplicity for Pagekit
# I appreciate all contributions!


Based on the Hello theme and One theme
 - Under development


## Install this theme

You can clone this repository or download all files from Github. Make sure this theme is located under `/packages/sondreg/theme-simplicity`.
