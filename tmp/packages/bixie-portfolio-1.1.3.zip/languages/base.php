<?php
return [
	'Don\'t show' => 'Don\'t show'
];