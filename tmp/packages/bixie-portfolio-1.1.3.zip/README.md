# Pagekit Portfolio

Bixies Portfolio for Pagekit lets you create a beautiful portfolio in your site.

Info and demo: [http://portfolio.bixie.org](http://portfolio.bixie.org).

## Installation

Please install Formmaker via the built-in Marketplace in your Pagekit Installation.

![image](http://portfolio.bixie.org/storage/marketplace_portfolio.jpg)

The extension and all its dependancies will be installed automatically.

## Issues and feature requests

Please use the [issues section](https://github.com/Bixie/pagekit-portfolio/issues) to file any bugs or feature requests.