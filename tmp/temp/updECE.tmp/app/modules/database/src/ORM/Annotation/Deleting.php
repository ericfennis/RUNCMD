<?php

namespace Pagekit\Database\ORM\Annotation;

/**
 * @Annotation
 * @Target("METHOD")
 */
final class Deleting implements Annotation
{
}
