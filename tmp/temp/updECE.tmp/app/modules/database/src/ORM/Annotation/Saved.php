<?php

namespace Pagekit\Database\ORM\Annotation;

/**
 * @Annotation
 * @Target("METHOD")
 */
final class Saved implements Annotation
{
}
